from flask import Flask, request, redirect, url_for, session, flash, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import secrets
import string

# ----------------------------
# APP CONFIGURATION

# ----------------------------
app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  

db = SQLAlchemy(app)

# ----------------------
# Database Models 
# ----------------------

# User/Customer table
class User(db.Model):
    __tablename__ = "customer"
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(265), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    bookings = db.relationship("Booking", backref="customer", lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Attraction table
class Attraction(db.Model):
    __tablename__ = "attraction"
    id = db.Column(db.Integer, primary_key=True)
    name_of_ride = db.Column(db.String(100), nullable=False)
    age_limit = db.Column(db.Integer)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text)

    bookings = db.relationship("Booking", backref="attraction", lazy=True)

# Ticket Availability table
class TicketAvailability(db.Model):
    __tablename__ = "ticket_availability"
    id = db.Column(db.Integer, primary_key=True)
    attraction_id = db.Column(db.Integer, db.ForeignKey("attraction.id"), nullable=False)
    visit_date = db.Column(db.Date, nullable=False)
    total_ticket = db.Column(db.Integer, default=2000)
    remaining_ticket = db.Column(db.Integer, default=2000)

    __table_args__ = (db.UniqueConstraint("attraction_id", "visit_date", name='_attraction_date_uc'),)

# Bookings table
class Booking(db.Model):
    __tablename__ = "booking"
    id = db.Column(db.Integer, primary_key=True)
    booking_reference = db.Column(db.String(50), unique=True, nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey("customer.id"), nullable=False)
    attraction_id = db.Column(db.Integer, db.ForeignKey("attraction.id"), nullable=False)
    booking_date = db.Column(db.Date, nullable=False)
    number_of_tickets = db.Column(db.Integer, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default="confirmed")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# -------------------
# Helper Functions
# -------------------

def generate_booking_reference():
    """Generate a unique booking reference"""
    characters = string.ascii_uppercase + string.digits
    while True:
        reference = 'WW-' + ''.join(secrets.choice(characters) for _ in range(8))
        if not Booking.query.filter_by(booking_reference=reference).first():
            return reference

def init_db():
    """Initialize database with sample attractions"""
    with app.app_context():
        db.create_all()
        
        # Check if attractions already exist
        if Attraction.query.count() == 0:
            attractions = [
                Attraction(name_of_ride="Santa's Grotto", age_limit=0, price=40.00, 
                          description="Meet Santa Claus in his magical grotto"),
                Attraction(name_of_ride="Ice Skating Rink", age_limit=5, price=30.00,
                          description="Glide across our beautiful outdoor ice rink"),
                Attraction(name_of_ride="Elf Workshop", age_limit=3, price=15.00,
                          description="Help Santa's elves create magical toys"),
                Attraction(name_of_ride="Christmas Market", age_limit=0, price=0.00,
                          description="Browse festive gifts and treats"),
                Attraction(name_of_ride="Magical Carousel", age_limit=3, price=35.00,
                          description="Ride on our enchanted carousel"),
                Attraction(name_of_ride="Winter Train Ride", age_limit=0, price=25.00,
                          description="Journey through our winter wonderland")
            ]
            
            for attraction in attractions:
                db.session.add(attraction)
            
            db.session.commit()
            print("Database initialized with sample attractions!")

# ----------------------
# Routes
# ----------------------

@app.route('/')
def index():
    """Homepage with attractions"""
    attractions = Attraction.query.all()
    return render_template("index.html", attractions=attractions)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    """User registration"""
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if not all([first_name, last_name, email, password, confirm_password]):
            flash('All fields are required!', 'error')
            return render_template('signup.html')
        
        if password != confirm_password:
            flash('Passwords do not match!', 'error')
            return render_template('signup.html')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters long!', 'error')
            return render_template('signup.html')
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            flash('Email already registered!', 'error')
            return render_template('signup.html')
        
        # Create new user
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email
        )
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Account created successfully! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.first_name
            flash('Welcome back!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password!', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """User logout"""
    session.clear()
    flash('You have been logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/booking', methods=['GET', 'POST'])
def booking():
    """Booking page"""
    if 'user_id' not in session:
        flash('Please login to book tickets!', 'error')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        attraction_id = request.form.get('attraction_id')
        booking_date = request.form.get('booking_date')
        num_tickets = int(request.form.get('num_tickets', 1))
        
        # Validation
        if not all([attraction_id, booking_date, num_tickets]):
            flash('All fields are required!', 'error')
            return redirect(url_for('booking'))
        
        # Convert date string to date object
        try:
            visit_date = datetime.strptime(booking_date, '%Y-%m-%d').date()
        except ValueError:
            flash('Invalid date format!', 'error')
            return redirect(url_for('booking'))
        
        # Check if date is in the future
        if visit_date < date.today():
            flash('Please select a future date!', 'error')
            return redirect(url_for('booking'))
        
        # Get attraction
        attraction = Attraction.query.get(attraction_id)
        if not attraction:
            flash('Invalid attraction!', 'error')
            return redirect(url_for('booking'))
        
        # Check/create ticket availability
        availability = TicketAvailability.query.filter_by(
            attraction_id=attraction_id,
            visit_date=visit_date
        ).first()
        
        if not availability:
            availability = TicketAvailability(
                attraction_id=attraction_id,
                visit_date=visit_date
            )
            db.session.add(availability)
            db.session.commit()
        
        # Check if enough tickets available
        if availability.remaining_ticket < num_tickets:
            flash(f'Sorry, only {availability.remaining_ticket} tickets available for this date!', 'error')
            return redirect(url_for('booking'))
        
        # Create booking
        total_price = attraction.price * num_tickets
        new_booking = Booking(
            booking_reference=generate_booking_reference(),
            customer_id=session['user_id'],
            attraction_id=attraction_id,
            booking_date=visit_date,
            number_of_tickets=num_tickets,
            total_price=total_price
        )
        
        # Update availability
        availability.remaining_ticket -= num_tickets
        
        db.session.add(new_booking)
        db.session.commit()
        
        return redirect(url_for('booking_confirmation', booking_id=new_booking.id))
    
    attractions = Attraction.query.all()
    return render_template('booking.html', attractions=attractions)

@app.route('/booking-confirmation/<int:booking_id>')
def booking_confirmation(booking_id):
    """Booking confirmation page"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if booking belongs to logged-in user
    if booking.customer_id != session['user_id']:
        flash('Unauthorized access!', 'error')
        return redirect(url_for('index'))
    
    return render_template('booking_confirmation.html', booking=booking)

@app.route('/account')
def account():
    """User account page"""
    if 'user_id' not in session:
        flash('Please login to view your account!', 'error')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    bookings = Booking.query.filter_by(customer_id=session['user_id']).order_by(Booking.created_at.desc()).all()
    
    return render_template('account.html', user=user, bookings=bookings)

@app.route('/cancel-booking/<int:booking_id>', methods=['POST'])
def cancel_booking(booking_id):
    """Cancel a booking"""
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if booking belongs to logged-in user
    if booking.customer_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Unauthorized access'}), 403
    
    # Check if booking is already cancelled
    if booking.status == 'cancelled':
        return jsonify({'success': False, 'message': 'Booking already cancelled'}), 400
    
    # Update booking status
    booking.status = 'cancelled'
    
    # Restore ticket availability
    availability = TicketAvailability.query.filter_by(
        attraction_id=booking.attraction_id,
        visit_date=booking.booking_date
    ).first()
    
    if availability:
        availability.remaining_ticket += booking.number_of_tickets
    
    db.session.commit()
    
    flash('Booking cancelled successfully!', 'success')
    return jsonify({'success': True, 'message': 'Booking cancelled successfully'})

@app.route('/more')
def more():
    """Additional information page"""
    return render_template('more.html')

@app.route('/api/check-availability')
def check_availability():
    """API endpoint to check ticket availability"""
    attraction_id = request.args.get('attraction_id')
    visit_date = request.args.get('date')
    
    if not attraction_id or not visit_date:
        return jsonify({'error': 'Missing parameters'}), 400
    
    try:
        visit_date = datetime.strptime(visit_date, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'error': 'Invalid date format'}), 400
    
    availability = TicketAvailability.query.filter_by(
        attraction_id=attraction_id,
        visit_date=visit_date
    ).first()
    
    if availability:
        remaining = availability.remaining_ticket
    else:
        remaining = 2000  # Default availability
    
    return jsonify({'available': remaining})

# Error handlers
@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

# -------------------
# Run Application
# -------------------

if __name__ == '__main__':
    init_db()
    app.run(debug=True)