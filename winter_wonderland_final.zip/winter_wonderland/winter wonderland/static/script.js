// =============================
// Navigation Scroll Effect
// =============================

const header = document.querySelector('.header');
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLink');

window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
});

// =============================
// Mobile Menu Toggle
// =============================

menuToggle?.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    menuToggle.classList.toggle('active');
});

// Close menu when clicking on a link
document.querySelectorAll('.navlink').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
        menuToggle?.classList.remove('active');
    });
});





// =============================
// Hero Carousel
// =============================

class Carousel {
    constructor() {
        this.currentSlide = 0;
        this.slides = document.querySelectorAll('.carousal-slide');
        this.indicators = document.querySelectorAll('.indicator');
        this.prevBtn = document.getElementById('prevSlide');
        this.nextBtn = document.getElementById('nextSlide');
        this.autoplayInterval = null;
        
        this.init();
    }
    
    init() {
        // Set initial slide
        this.showSlide(0);
        
        // Event listeners
        this.prevBtn?.addEventListener('click', () => this.prevSlide());
        this.nextBtn?.addEventListener('click', () => this.nextSlide());
        
        // Indicator clicks
        this.indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => this.showSlide(index));
        });
        
        // Start autoplay
        this.startAutoplay();
        
        // Pause on hover
        const carousel = document.querySelector('.carousal');
        carousel?.addEventListener('mouseenter', () => this.stopAutoplay());
        carousel?.addEventListener('mouseleave', () => this.startAutoplay());
    }
    
    showSlide(index) {
        // Remove active class from all slides and indicators
        this.slides.forEach(slide => slide.classList.remove('active'));
        this.indicators.forEach(indicator => indicator.classList.remove('active'));
        
        // Add active class to current slide and indicator
        this.slides[index]?.classList.add('active');
        this.indicators[index]?.classList.add('active');
        
        this.currentSlide = index;
        
        // Animate slide content
        this.animateSlideContent();
    }
    
    animateSlideContent() {
        const activeSlide = this.slides[this.currentSlide];
        const content = activeSlide?.querySelector('.slide-content');
        
        if (content) {
            content.style.animation = 'none';
            setTimeout(() => {
                content.style.animation = 'fadeInUp 1.2s ease forwards';
            }, 10);
        }
    }
    
    nextSlide() {
        const next = (this.currentSlide + 1) % this.slides.length;
        this.showSlide(next);
    }
    
    prevSlide() {
        const prev = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
        this.showSlide(prev);
    }
    
    startAutoplay() {
        this.stopAutoplay();
        this.autoplayInterval = setInterval(() => this.nextSlide(), 5000);
    }
    
    stopAutoplay() {
        if (this.autoplayInterval) {
            clearInterval(this.autoplayInterval);
        }
    }
}

// Initialize carousel
if (document.querySelector('.carousal')) {
    new Carousel();
}

// =============================
// Stats Counter Animation
// =============================

class StatsCounter {
    constructor() {
        this.counters = document.querySelectorAll('.stat-number');
        this.animated = false;
        this.init();
    }
    
    init() {
        if (this.counters.length === 0) return;
        
        // Create intersection observer
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && !this.animated) {
                    this.animateCounters();
                    this.animated = true;
                }
            });
        }, { threshold: 0.5 });
        
        // Observe stats section
        const statsSection = document.querySelector('.stats-wrapper');
        if (statsSection) {
            observer.observe(statsSection);
        }
    }
    
    animateCounters() {
        this.counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const duration = 2000;
            const increment = target / (duration / 16);
            let current = 0;
            
            const updateCounter = () => {
                current += increment;
                if (current < target) {
                    counter.textContent = Math.floor(current);
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target;
                }
            };
            
            updateCounter();
        });
    }
}

// Initialize stats counter
new StatsCounter();

// =============================
// Scroll Animations
// =============================

class ScrollAnimations {
    constructor() {
        this.elements = document.querySelectorAll('.discover-card, .section-header');
        this.init();
    }
    
    init() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '0';
                    entry.target.style.transform = 'translateY(50px)';
                    
                    setTimeout(() => {
                        entry.target.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }, 100);
                    
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        this.elements.forEach(element => observer.observe(element));
    }
}

// Initialize scroll animations
new ScrollAnimations();

// =============================
// Smooth Scroll for Anchor Links
// =============================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && href !== '') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                const headerOffset = 100;
                const elementPosition = target.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        }
    });
});

// =============================
// Scroll Progress Bar
// =============================

function updateScrollProgress() {
    const scrollProgress = document.createElement('div');
    scrollProgress.classList.add('scroll-progress');
    document.body.appendChild(scrollProgress);
    
    window.addEventListener('scroll', () => {
        const windowHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (window.pageYOffset / windowHeight) * 100;
        scrollProgress.style.width = scrolled + '%';
    });
}

updateScrollProgress();

// =============================
// Parallax Effect for Hero
// =============================

window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    
    if (hero) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// =============================
// Loading Animation
// =============================

window.addEventListener('load', () => {
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease';
        document.body.style.opacity = '1';
    }, 100);
});

// =============================
// Enhanced Button Ripple Effect
// =============================

document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', function(e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const ripple = document.createElement('span');
        ripple.style.cssText = `
            position: absolute;
            width: 20px;
            height: 20px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            pointer-events: none;
            animation: ripple 0.6s ease-out;
        `;
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        
        this.appendChild(ripple);
        
        setTimeout(() => ripple.remove(), 600);
    });
});

// Add ripple animation
const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            width: 300px;
            height: 300px;
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// =============================
// Form Validation Helper
// =============================

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showMessage(element, message, type = 'error') {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message message-${type}`;
    messageDiv.textContent = message;
    messageDiv.style.cssText = `
        padding: 15px 20px;
        margin: 15px 0;
        border-radius: 8px;
        font-size: 0.95rem;
        animation: slideDown 0.3s ease;
        background: ${type === 'error' ? 'rgba(193, 18, 31, 0.2)' : 'rgba(76, 175, 80, 0.2)'};
        border: 1px solid ${type === 'error' ? 'var(--secondary-color)' : '#4CAF50'};
        color: ${type === 'error' ? 'var(--secondary-color)' : '#4CAF50'};
    `;
    
    element.insertBefore(messageDiv, element.firstChild);
    
    setTimeout(() => {
        messageDiv.style.animation = 'slideUp 0.3s ease';
        setTimeout(() => messageDiv.remove(), 300);
    }, 5000);
}

// Add animation styles
const messageStyle = document.createElement('style');
messageStyle.textContent = `
    @keyframes slideDown {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes slideUp {
        from {
            opacity: 1;
            transform: translateY(0);
        }
        to {
            opacity: 0;
            transform: translateY(-20px);
        }
    }
`;
document.head.appendChild(messageStyle);


document.addEventListener('DOMContentLoaded', () => {

    const widget = document.querySelector('.accessibility-widget');
    const trigger = document.querySelector('.accessibility-trigger');
    const panel = document.querySelector('.accessibility-panel');
    const closeBtn = document.querySelector('.accessibility-close');
    const options = document.querySelectorAll('.accessibility-option');

    // If widget doesn't exist on this page, STOP safely
    if (!widget || !trigger || !panel) return;

    /* =============================
       PANEL OPEN / CLOSE
       ============================= */

    function openPanel() {
        panel.classList.add('active');
        trigger.setAttribute('aria-expanded', 'true');
    }

    function closePanel() {
        panel.classList.remove('active');
        trigger.setAttribute('aria-expanded', 'false');
    }

    trigger.addEventListener('click', (e) => {
        e.stopPropagation();
        panel.classList.contains('active') ? closePanel() : openPanel();
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            closePanel();
        });
    }

    document.addEventListener('click', (e) => {
        if (!widget.contains(e.target)) {
            closePanel();
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closePanel();
        }
    });

/* =============================
ACCESSIBILITY OPTIONS
    ============================= */

let settings = {};
try {
    settings = JSON.parse(localStorage.getItem('accessibilitySettings')) || {};
} catch {
    settings = {};
}

options.forEach(option => {
    if (!option.dataset || !option.dataset.option) return;

    const key = option.dataset.option;
    const toggle = option.querySelector('.accessibility-toggle');
    if (!toggle) return;

    const className = key.replace(/[A-Z]/g, m => '-' + m.toLowerCase());

        // Load saved state
        if (settings[key]) {
            toggle.classList.add('active');
            document.body.classList.add(className);
        }

        option.addEventListener('click', (e) => {
            e.stopPropagation();

            toggle.classList.toggle('active');
            const enabled = toggle.classList.contains('active');

            document.body.classList.toggle(className, enabled);
            settings[key] = enabled;
            localStorage.setItem('accessibilitySettings', JSON.stringify(settings));
        });
    });

});
document.addEventListener("DOMContentLoaded", () => {

    const cancelButtons = document.querySelectorAll(".booking-cancel-btn");

    cancelButtons.forEach(button => {
        button.addEventListener("click", async () => {

            const bookingId = button.dataset.bookingId;
            const bookingCard = button.closest(".booking-card");

            if (!bookingId) return;

            if (!confirm("Are you sure you want to cancel this booking?")) return;

            button.disabled = true;
            button.textContent = "Cancelling...";

            try {
                const response = await fetch(`/cancel-booking/${bookingId}`, {
                    method: "POST",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                });

                // 🚨 If Flask returns HTML error page
                if (!response.ok) {
                    throw new Error(`Server error: ${response.status}`);
                }

                const data = await response.json();

                if (!data.success) {
                    throw new Error(data.message || "Cancellation failed");
                }

                /* UI UPDATE */
                bookingCard.classList.add("booking-cancelled");

                const status = bookingCard.querySelector(".booking-status");
                status.textContent = "cancelled";
                status.className = "booking-status status-cancelled";

                button.remove();

            } catch (error) {
                console.error("Cancel booking error:", error);
                alert("Failed to cancel booking. Please refresh and try again.");
                button.disabled = false;
                button.innerHTML = `<i class="ri-close-circle-line"></i> Cancel Booking`;
            }
        });
    });

});


// =============================
// Console Branding
// =============================

console.log('%c🎄 Winter Wonderland 🎄', 'font-size: 24px; font-weight: bold; color: #0B3C5D; text-shadow: 2px 2px 4px rgba(193, 18, 31, 0.3);');
console.log('%cWelcome to the magic of winter!', 'font-size: 14px; color: #C1121F;');